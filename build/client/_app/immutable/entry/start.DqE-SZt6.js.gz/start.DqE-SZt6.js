import{l as o,j as r}from"../chunks/CaZwOZBV.js";export{o as load_css,r as start};
